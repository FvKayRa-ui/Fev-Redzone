local QBCore = exports['qb-core']:GetCoreObject()

-- Script başlangıç mesajı
AddEventHandler('onResourceStart', function(resourceName)
    if (GetCurrentResourceName() ~= resourceName) then return end
    print('^2Fev-Redzone server başarıyla başlatıldı!^0')
end)

-- İleriye dönük geliştirmeler için server tarafı fonksiyonları buraya eklenebilir
-- Örneğin whitelist, redzone'da kalma süresi takibi, oyuncuya özel efektler vb.

-- Oyuncu sunucuya giriş yaptığında bilgilendirme
RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    TriggerClientEvent('Fev-Redzone:sendConfig', source, Config)
end)

-- Red zone ayarlarını güncelleme komutu (admin)
QBCore.Commands.Add('redzoneyonet', 'Red Zone ayarlarını yönet (Sadece Adminler)', {}, false, function(source, args)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if Player.PlayerData.permission ~= "admin" and Player.PlayerData.permission ~= "god" then
        TriggerClientEvent('QBCore:Notify', src, "Bu komutu kullanma yetkiniz yok!", "error")
        return
    end
    
    -- Basit bir menü sistemi olmadan komut parametreleriyle yönet
    if args[1] == "damage" and args[2] and tonumber(args[2]) then
        Config.RedZones[1].damage = tonumber(args[2])
        TriggerClientEvent('QBCore:Notify', src, "Red Zone hasar miktarı " .. args[2] .. " olarak güncellendi.", "success")
        TriggerClientEvent('Fev-Redzone:sendConfig', -1, Config)
    elseif args[1] == "interval" and args[2] and tonumber(args[2]) then
        Config.RedZones[1].interval = tonumber(args[2])
        TriggerClientEvent('QBCore:Notify', src, "Red Zone hasar aralığı " .. args[2] .. "ms olarak güncellendi.", "success")
        TriggerClientEvent('Fev-Redzone:sendConfig', -1, Config)
    elseif args[1] == "radius" and args[2] and tonumber(args[2]) then
        Config.RedZones[1].radius = tonumber(args[2])
        TriggerClientEvent('QBCore:Notify', src, "Red Zone yarıçapı " .. args[2] .. "m olarak güncellendi.", "success")
        TriggerClientEvent('Fev-Redzone:sendConfig', -1, Config)
    else
        TriggerClientEvent('QBCore:Notify', src, "Geçersiz parametre. Kullanım: /redzoneyonet [damage/interval/radius] [değer]", "error")
    end
end)

-- Config dosyasını istemciye gönder
RegisterNetEvent('Fev-Redzone:requestConfig', function()
    local src = source
    TriggerClientEvent('Fev-Redzone:sendConfig', src, Config)
end)
