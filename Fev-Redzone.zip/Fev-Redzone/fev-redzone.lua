--[[
    Fev-Redzone - QBCore uyumlu redzone scripti
    Yapımcı: Claude
    Tanım: Belirli bir alana giren oyuncuların canını azaltan script
]]--

local QBCore = exports['qb-core']:GetCoreObject()

-- Redzone bölgesinin koordinatları ve yarıçapı
local redZone = {
    center = vector3(1275.0, -1710.0, 54.0), -- Kırmızı bölgenin merkezini değiştirebilirsiniz
    radius = 50.0, -- Yarıçapı (metre cinsinden) değiştirebilirsiniz
    damage = 5, -- Her tick'te azaltılacak can miktarı
    interval = 1000, -- Can azaltma aralığı (milisaniye cinsinden)
    notification = true, -- Bildirim gösterimi açık/kapalı
    blip = true -- Haritada gösterim açık/kapalı
}

-- Blip oluşturma
if redZone.blip then
    CreateThread(function()
        local blip = AddBlipForRadius(redZone.center.x, redZone.center.y, redZone.center.z, redZone.radius)
        SetBlipHighDetail(blip, true)
        SetBlipColour(blip, 1) -- Kırmızı renk
        SetBlipAlpha(blip, 128) -- Yarı saydam

        local centerBlip = AddBlipForCoord(redZone.center.x, redZone.center.y, redZone.center.z)
        SetBlipSprite(centerBlip, 310) -- Tehlike işareti
        SetBlipDisplay(centerBlip, 4)
        SetBlipScale(centerBlip, 1.0)
        SetBlipColour(centerBlip, 1) -- Kırmızı
        SetBlipAsShortRange(centerBlip, true)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString("Tehlikeli Bölge")
        EndTextCommandSetBlipName(centerBlip)
    end)
end

-- Oyuncunun red zone içinde olup olmadığını kontrol etme
local function IsPlayerInRedZone(playerCoords)
    local distance = #(playerCoords - redZone.center)
    return distance <= redZone.radius
end

-- Ana işlev döngüsü
CreateThread(function()
    local inZone = false
    local notificationShown = false

    while true do
        local playerPed = PlayerPedId()
        local playerCoords = GetEntityCoords(playerPed)
        local isInZone = IsPlayerInRedZone(playerCoords)

        if isInZone then
            if not inZone and redZone.notification then
                -- Bölgeye ilk giriş
                QBCore.Functions.Notify("Tehlikeli bölgeye girdiniz! Can kaybı yaşayacaksınız.", "error", 5000)
                notificationShown = true
            end

            inZone = true
            
            -- Sağlık değerini azalt
            local health = GetEntityHealth(playerPed)
            if health > 0 then
                SetEntityHealth(playerPed, health - redZone.damage)
            end
            
            -- Ekrana kırmızımsı bir efekt ver
            DrawLightWithRange(playerCoords.x, playerCoords.y, playerCoords.z, 255, 0, 0, 2.0, 0.5)
            SetTimecycleModifier("damage")
            Wait(redZone.interval)
        else
            if inZone and redZone.notification then
                -- Bölgeden çıkış
                QBCore.Functions.Notify("Tehlikeli bölgeden çıktınız.", "success", 5000)
                notificationShown = false
            end
            
            inZone = false
            ClearTimecycleModifier()
            Wait(1000)
        end
    end
end)

-- Bölge sınırlarını görselleştirme (Debug için)
CreateThread(function()
    while true do
        local playerCoords = GetEntityCoords(PlayerPedId())
        local distance = #(playerCoords - redZone.center)
        
        if distance <= redZone.radius + 100.0 then
            -- Redzone çevresini çiz (sadece yakındayken)
            DrawMarker(1, redZone.center.x, redZone.center.y, redZone.center.z - 1.0, 
                      0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 
                      redZone.radius * 2.0, redZone.radius * 2.0, 2.0, 
                      255, 0, 0, 50, false, false, 2, nil, nil, false)
            Wait(0)
        else
            Wait(1000)
        end
    end
end)

print("^2Fev-Redzone başarıyla başlatıldı!^7")
