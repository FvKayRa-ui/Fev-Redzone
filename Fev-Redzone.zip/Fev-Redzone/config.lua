Config = {}

Config.RedZones = {
    {
        center = vector3(1275.0, -1710.0, 54.0), -- Kırmızı bölgenin merkezi
        radius = 50.0,                           -- Bölgenin yarıçapı (metre)
        damage = 5,                              -- Her tick'te azaltılacak can miktarı
        interval = 1000,                         -- Can azaltma aralığı (ms)
        blipColor = 1,                           -- Blip rengi (1 = kırmızı)
        blipAlpha = 128,                         -- Blip saydamlığı (0-255)
        blipSprite = 310,                        -- Merkez blip simgesi
        blipName = "Tehlikeli Bölge"             -- Haritada görünecek isim
    },
    -- İstenirse buraya daha fazla bölge eklenebilir
    --[[
    {
        center = vector3(1000.0, -1000.0, 40.0),
        radius = 30.0,
        damage = 10,
        interval = 2000,
        blipColor = 1,
        blipAlpha = 128,
        blipSprite = 310,
        blipName = "Çok Tehlikeli Bölge"
    },
    ]]--
}

Config.Notification = true       -- Bildirim gösterimi açık/kapalı
Config.BlipEnabled = true        -- Haritada gösterim açık/kapalı
Config.VisualEffect = true       -- Kırmızı efekt açık/kapalı
Config.DrawDebugZone = false     -- Debug modunda zone'u görselleştirme
