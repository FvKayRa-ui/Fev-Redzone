local QBCore = exports['qb-core']:GetCoreObject()
local inZone = false
local activeZones = {}

-- Blipler için fonksiyon
local function CreateZoneBlips()
    if not Config.BlipEnabled then return end
    
    for i, zone in ipairs(Config.RedZones) do
        -- Ana alan için blip oluştur (çember)
        local blip = AddBlipForRadius(zone.center.x, zone.center.y, zone.center.z, zone.radius)
        SetBlipHighDetail(blip, true)
        SetBlipColour(blip, zone.blipColor)
        SetBlipAlpha(blip, zone.blipAlpha)
        
        -- Merkez nokta için blip
        local centerBlip = AddBlipForCoord(zone.center.x, zone. center.y, zone.center.z)
        SetBlipSprite(centerBlip, zone.blipSprite)
        SetBlipDisplay(centerBlip, 4)
        SetBlipScale(centerBlip, 1.0)
        SetBlipColour(centerBlip, zone.blipColor)
        SetBlipAsShortRange(centerBlip, true)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString(zone.blipName)
        EndTextCommandSetBlipName(centerBlip)
        
        table.insert(activeZones, {
            zoneId = i,
            radiusBlip = blip,
            centerBlip = centerBlip,
            inZone = false
        })
    end
end

-- Oyuncunun herhangi bir red zone içinde olup olmadığını kontrol etme
local function CheckPlayerInRedZone(playerCoords)
    local isInAnyZone = false
    
    for i, zoneData in ipairs(activeZones) do
        local zone = Config.RedZones[zoneData.zoneId]
        local distance = #(playerCoords - zone.center)
        local isInThisZone = distance <= zone.radius
        
        -- Oyuncu bu bölgeye girdi mi?
        if isInThisZone and not zoneData.inZone then
            if Config.Notification then
                QBCore.Functions.Notify("Tehlikeli bölgeye girdiniz! Can kaybı yaşayacaksınız.", "error", 5000)
            end
            zoneData.inZone = true
        end
        
        -- Oyuncu bu bölgeden çıktı mı?
        if not isInThisZone and zoneData.inZone then
            if Config.Notification then
                QBCore.Functions.Notify("Tehlikeli bölgeden çıktınız.", "success", 5000)
            end
            zoneData.inZone = false
        end
        
        -- Oyuncu herhangi bir bölgede mi?
        if isInThisZone then
            isInAnyZone = true
        end
    end
    
    return isInAnyZone
end

-- Red zone içinde oyuncuya hasar verme
local function ApplyZoneDamage()
    local playerPed = PlayerPedId()
    
    for _, zoneData in ipairs(activeZones) do
        if zoneData.inZone then
            local zone = Config.RedZones[zoneData.zoneId]
            local health = GetEntityHealth(playerPed)
            
            if health > 0 then
                SetEntityHealth(playerPed, math.max(0, health - zone.damage))
            end
            
            if Config.VisualEffect then
                SetTimecycleModifier("damage")
            end
            
            return -- En azından bir bölgede hasar aldıysa döngüden çık
        end
    end
    
    -- Hiçbir bölgede değilse efekti temizle
    if Config.VisualEffect then
        ClearTimecycleModifier()
    end
end

-- Red zone sınırlarını görselleştirme (Debug mod)
local function DrawZones()
    if not Config.DrawDebugZone then return end
    
    for i, zone in ipairs(Config.RedZones) do
        DrawMarker(1, zone.center.x, zone.center.y, zone.center.z - 1.0, 
                  0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 
                  zone.radius * 2.0, zone.radius * 2.0, 2.0, 
                  255, 0, 0, 50, false, false, 2, nil, nil, false)
    end
end

-- Ana işlev döngüleri
CreateThread(function()
    CreateZoneBlips()
    
    -- Ana kontrol döngüsü
    while true do
        local playerPed = PlayerPedId()
        local playerCoords = GetEntityCoords(playerPed)
        inZone = CheckPlayerInRedZone(playerCoords)
        
        if inZone then
            ApplyZoneDamage()
            Wait(Config.RedZones[1].interval) -- İlk zonu kullan (çoklu zon desteği için geliştirilebilir)
        else
            Wait(1000) -- Zone dışındayken kontrol aralığını arttır (performans için)
        end
    end
end)

-- Görselleştirme döngüsü (Debug mod)
CreateThread(function()
    while true do
        local playerCoords = GetEntityCoords(PlayerPedId())
        local inRange = false
        
        -- Herhangi bir zone'a yakın mı kontrol et
        for _, zone in ipairs(Config.RedZones) do
            local distance = #(playerCoords - zone.center)
            if distance <= zone.radius + 100.0 then
                inRange = true
                break
            end
        end
        
        if inRange then
            DrawZones()
            Wait(0)
        else
            Wait(1000) -- Uzaktayken daha seyrek kontrol et
        end
    end
end)

print("^2Fev-Redzone client başarıyla başlatıldı!^7")
